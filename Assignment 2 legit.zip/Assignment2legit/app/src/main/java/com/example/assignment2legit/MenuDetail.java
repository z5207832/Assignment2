package com.example.assignment2legit;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MenuDetail extends AppCompatActivity {

    private TextView nameTextView;
    private TextView costTextView;
    private TextView descTextView;
    private ImageView imageView;
    private TextView quantityTextView;
    private TextView totalCostTextView;
    private Button addItem;
    private Button add;
    private Button minus;

    int amount = 0;
    double cost = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        Intent intent = getIntent();
        int foodPosition = intent.getIntExtra("foodID", -1);
        final ItemMenu currentFood = ItemMenuList.getItemMenuByID(foodPosition);


        nameTextView = findViewById(R.id.itemMenuName2);
        costTextView = findViewById(R.id.itemMenuPrice);
        descTextView = findViewById(R.id.itemMenuDescription);
        imageView = findViewById(R.id.itemMenuImage2);



        nameTextView.setText(currentFood.getFoodName());
        costTextView.setText(String.format("$" + "%.2f" ,currentFood.getFoodCost()));
        totalCostTextView.setText("$0.00");
        descTextView.setText(currentFood.getFoodDesc());
        imageView.setImageResource(currentFood.getImageDrawableId());
        quantityTextView.setText(String.valueOf(amount));



        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (amount > 0) {
                    amount -= 1;
                    quantityTextView.setText(String.valueOf(amount));
                    cost = currentFood.getFoodCost() * amount;
                    totalCostTextView.setText(String.format("$" + "%.2f", cost));
                    currentFood.setItemCount(amount);
                    currentFood.setTotalCost(cost);
                } else {
                    Toast.makeText(getApplicationContext(), "Please choose number of items", Toast.LENGTH_SHORT).show();
                }
            }
        });
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                amount += 1;
                quantityTextView.setText(String.valueOf(amount));

                cost = currentFood.getFoodCost() * amount;
                totalCostTextView.setText(String.format("$" + "%.2f", cost));
                currentFood.setItemCount(amount);
                currentFood.setTotalCost(cost);


            }
        });

    }



}
