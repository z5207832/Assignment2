package com.example.assignment2legit;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class ItemMenuList {

        public static ItemMenu getItemMenuByID(int itemMenuID) {
            return itemMenus.get(itemMenuID);
        }

        public static ArrayList<ItemMenu> getAllItemMenus() {
            return new ArrayList<ItemMenu>((List) Arrays.asList(itemMenus.values().toArray()));
        }

        private static final HashMap<Integer, ItemMenu> itemMenus = new HashMap<>();

        static {
            itemMenus.put(1, new ItemMenu(
                    1,
                    R.drawable.bopperburger,
                    "Bopper",
                    5.00,
                    "The classic Bopper with double beef patty, tomato, lettuce and special sauce",
                    0
            ));
            itemMenus.put(2, new ItemMenu(
                    2,
                    R.drawable.bopperburger,
                    "Bopper Jnr",
                    5.00,
                    "Single beef patty, tomatto, lettuce and special sauce",
                    0
            ));
            itemMenus.put(3, new ItemMenu(
                    3,
                    R.drawable.fishburger,
                    "Fish Burger",
                    5.00,
                    "Fish fillet and tartar sauce",
                    0
            ));
            itemMenus.put(4, new ItemMenu(
                    4,
                    R.drawable.veggieburger,
                    "Veggie Burger",
                    5.00,
                    "A burger for plebs",
                    0
            ));
            itemMenus.put(5, new ItemMenu(
                    5,
                    R.drawable.veggiewrap,
                    "Veggie Wrap",
                    5.00,
                    "A wrap for plebs",
                    0
            ));
            itemMenus.put(6, new ItemMenu(
                    6,
                    R.drawable.chickenwrap,
                    "Chicken Wrap",
                    5.00,
                    "A chicken wrap",
                    0
            ));
            itemMenus.put(7, new ItemMenu(
                    7,
                    R.drawable.caesarsalad,
                    "Caesar Salad",
                    5.00,
                    "A caesar salad",
                    0
            ));
            itemMenus.put(8, new ItemMenu(
                    8,
                    R.drawable.chickensalad,
                    "Chicken Salad",
                    5.00,
                    "A chicken Salad",
                    0
            ));
            itemMenus.put(9, new ItemMenu(
                    9,
                    R.drawable.chips,
                    "Chips",
                    2.50,
                    "Chips (200g)",
                    0
            ));
            itemMenus.put(10, new ItemMenu(
                    10,
                    R.drawable.onionrings,
                    "Onion Rings",
                    2.50,
                    "Onion rings (200g)",
                    0
            ));
            itemMenus.put(11, new ItemMenu(
                    11,
                    R.drawable.sprite,
                    "Sprite",
                    2.50,
                    "375mL can of Sprite",
                    0
            ));
            itemMenus.put(12, new ItemMenu(
                    12,
                    R.drawable.fanta,
                    "Fanta",
                    2.50,
                    "375mL can of Fanta",
                    0
            ));
            itemMenus.put(13, new ItemMenu(
                    12,
                    R.drawable.coke,
                    "Coca Cola",
                    2.50,
                    "375mL can of Coke",
                    0
            ));
            itemMenus.put(14, new ItemMenu(
                    14,
                    R.drawable.pepsi,
                    "Pepsi",
                    2.50,
                    "375mL can of Pepsi",
                    0
            ));
            itemMenus.put(15, new ItemMenu(
                    15,
                    R.drawable.thickshake,
                    "Thicccccshake",
                    2.50,
                    "500mL signature chocolate milkshake",
                    0
            ));
        }
}
