package com.example.assignment2legit;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;



import java.util.ArrayList;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.MenuViewHolder> {
    private ArrayList<ItemMenu> menuToAdapt;

    public void setData(ArrayList<ItemMenu>menuToAdapt){

        this.menuToAdapt = menuToAdapt;
    }

    @NonNull
    @Override
    public MenuViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_menu, parent, false);
        MenuViewHolder menuViewHolder = new MenuViewHolder(view);
        return menuViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MenuViewHolder holder, int position) {
        final ItemMenu foodAtPosition = menuToAdapt.get(position);

        holder.itemMenuName.setText(foodAtPosition.getFoodName());
        holder.itemMenuPrice2.setText(String.format("$" + "%.2f" ,foodAtPosition.getFoodCost()));
        //holder.desc.setText(foodAtPosition.getFoodDesc());
        holder.itemMenuImage.setImageResource(foodAtPosition.getImageDrawableId());
        holder.view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context context = view.getContext();
                Intent intent = new Intent(context, MenuDetail.class);
                intent.putExtra("foodID", foodAtPosition.getFoodID());
                context.startActivity(intent);

            }
        });


    }


    @Override
    public int getItemCount() {
        return menuToAdapt.size();
    }

    public static class MenuViewHolder extends RecyclerView.ViewHolder{
        public View view;
        public ImageView itemMenuImage;
        public TextView itemMenuName;
        public TextView itemMenuPrice2;

        public MenuViewHolder(View v) {
            super(v);
            view = v;
            itemMenuImage = v.findViewById(R.id.itemMenuImage);
            itemMenuName = v.findViewById(R.id.itemMenuName);
            itemMenuPrice2 = v.findViewById(R.id.itemMenuPrice2);
        }
    }
}